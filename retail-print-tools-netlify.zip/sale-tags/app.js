const TOTAL_TAGS = 12;

const CODE_128_PATTERNS = [
  "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312",
  "132212", "221213", "221312", "231212", "112232", "122132", "122231", "113222",
  "123122", "123221", "223211", "221132", "221231", "213212", "223112", "312131",
  "311222", "321122", "321221", "312212", "322112", "322211", "212123", "212321",
  "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
  "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121",
  "313121", "211331", "231131", "213113", "213311", "213131", "311123", "311321",
  "331121", "312113", "312311", "332111", "314111", "221411", "431111", "111224",
  "111422", "121124", "121421", "141122", "141221", "112214", "112412", "122114",
  "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
  "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112",
  "421211", "212141", "214121", "412121", "111143", "111341", "131141", "114113",
  "114311", "411113", "411311", "113141", "114131", "311141", "411131", "211412",
  "211214", "211232", "2331112"
];

const state = {
  tags: Array.from({ length: TOTAL_TAGS }, () => null),
  activeIndex: 0
};

const fields = {
  description: document.querySelector("#description"),
  size: document.querySelector("#size"),
  upc: document.querySelector("#upc"),
  orderNumber: document.querySelector("#orderNumber"),
  salePrice: document.querySelector("#salePrice"),
  savings: document.querySelector("#savings"),
  endDate: document.querySelector("#endDate")
};

const sheet = document.querySelector("#tagSheet");
const form = document.querySelector("#tagForm");
const statusText = document.querySelector("#statusText");
const activeLabelText = document.querySelector("#activeLabelText");
const filledCount = document.querySelector("#filledCount");
const pageNotice = document.querySelector("#pageNotice");
const addButton = document.querySelector("#addButton");
const undoButton = document.querySelector("#undoButton");

function init() {
  const saved = localStorage.getItem("sale-tag-maker-state");
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed.tags) && parsed.tags.length === TOTAL_TAGS) {
        state.tags = parsed.tags;
        state.activeIndex = Math.min(parsed.activeIndex || firstOpenIndex(), TOTAL_TAGS - 1);
      }
    } catch {
      localStorage.removeItem("sale-tag-maker-state");
    }
  }

  renderSheet();
  updateStatus();
  fields.description.focus();
}

function save() {
  localStorage.setItem("sale-tag-maker-state", JSON.stringify(state));
}

function firstOpenIndex() {
  const open = state.tags.findIndex((tag) => !tag);
  return open === -1 ? TOTAL_TAGS - 1 : open;
}

function cleanMoney(value) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (trimmed.includes("/") || trimmed.startsWith("$")) return trimmed;
  return `$${trimmed}`;
}

function currentFormData() {
  return {
    description: fields.description.value.trim(),
    size: fields.size.value.trim(),
    upc: fields.upc.value.trim(),
    orderNumber: fields.orderNumber.value.trim(),
    salePrice: cleanMoney(fields.salePrice.value),
    savings: fields.savings.value.trim(),
    endDate: fields.endDate.value.trim()
  };
}

function clearForm() {
  form.reset();
  fields.description.focus();
}

function advance() {
  const open = state.tags.findIndex((tag, index) => !tag && index > state.activeIndex);
  state.activeIndex = open === -1 ? firstOpenIndex() : open;
}

function renderSheet() {
  sheet.innerHTML = "";
  state.tags.forEach((tag, index) => {
    const item = document.createElement("button");
    item.type = "button";
    item.className = `sale-tag ${tag ? "" : "empty"} ${index === state.activeIndex ? "active" : ""}`;
    item.setAttribute("aria-label", `Tag ${index + 1}`);
    item.addEventListener("click", () => {
      state.activeIndex = index;
      if (state.tags[index]) loadTagIntoForm(state.tags[index]);
      renderSheet();
      updateStatus();
      save();
    });

    if (!tag) {
      item.textContent = index + 1;
    } else {
      item.appendChild(tagContent(tag));
    }

    sheet.appendChild(item);
  });
}

function tagContent(tag) {
  const wrap = document.createElement("div");
  wrap.className = "tag-body";
  wrap.innerHTML = `
    <div class="top-strip">
      <div class="description"></div>
      <div class="size-value"></div>
      <div class="item-codes"></div>
    </div>
    <div class="sale-banner"><span>on</span><span>SALE!</span></div>
    <div class="price-panel"><div class="sale-price"></div></div>
    <div class="footer-strip">
      <div class="save-label">save</div>
      <div class="savings-box"></div>
      <div class="end-date"></div>
    </div>
  `;
  wrap.querySelector(".description").textContent = tag.description;
  wrap.querySelector(".size-value").textContent = tag.size;
  wrap.querySelector(".item-codes").innerHTML = `${escapeHtml(tag.upc)}<br>${escapeHtml(tag.orderNumber)}`;
  wrap.querySelector(".sale-price").textContent = tag.salePrice;
  wrap.querySelector(".savings-box").textContent = tag.savings;
  wrap.querySelector(".end-date").innerHTML = `sale ends<br>${escapeHtml(tag.endDate)}`;
  return wrap;
}

function loadTagIntoForm(tag) {
  fields.description.value = tag.description;
  fields.size.value = tag.size;
  fields.upc.value = tag.upc;
  fields.orderNumber.value = tag.orderNumber;
  fields.salePrice.value = tag.salePrice.replace(/^\$/, "");
  fields.savings.value = tag.savings;
  fields.endDate.value = tag.endDate;
}

function updateStatus() {
  const count = state.tags.filter(Boolean).length;
  filledCount.textContent = count;
  undoButton.disabled = state.activeIndex === 0 && !state.tags[0];
  pageNotice.hidden = count !== TOTAL_TAGS;
  addButton.textContent = state.tags[state.activeIndex] ? "Update Tag" : "Add Tag";

  if (count === TOTAL_TAGS) {
    statusText.textContent = "Page filled. Ready for printing.";
    activeLabelText.textContent = "All 12 sale tags are filled";
  } else {
    statusText.textContent = `Tag ${state.activeIndex + 1} of ${TOTAL_TAGS} is ready.`;
    activeLabelText.textContent = `Filling tag ${state.activeIndex + 1}`;
  }
}

function exportPdf() {
  const pdf = createSaleTagPdf(state.tags);
  const blob = new Blob([pdf], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "sale-tags.pdf";
  link.click();
  URL.revokeObjectURL(url);
}

function createSaleTagPdf(tags) {
  const pageWidth = 612;
  const pageHeight = 792;
  const marginX = 13;
  const marginY = 31;
  const tagWidth = 145.75;
  const tagHeight = 242;
  const gapX = 4;
  const gapY = 4;
  const commands = [];

  tags.forEach((tag, index) => {
    if (!tag) return;
    const row = Math.floor(index / 4);
    const col = index % 4;
    const x = marginX + col * (tagWidth + gapX);
    const y = marginY + row * (tagHeight + gapY);
    drawSaleTag(commands, tag, x, y, tagWidth, tagHeight, pageHeight);
  });

  return buildPdf(pageWidth, pageHeight, commands.join("\n"));
}

function drawSaleTag(commands, tag, x, y, width, height, pageHeight) {
  drawText(commands, tag.description.toUpperCase(), x + 13, y + 17, pageHeight, 8, "F2", "0 0 0 rg");
  drawText(commands, tag.upc, x + 13, y + 32, pageHeight, 6, "F2");
  drawText(commands, tag.orderNumber, x + 13, y + 44, pageHeight, 6, "F2");
  drawRightText(commands, tag.size, x + width - 13, y + 44, pageHeight, 6, "F2");

  drawCenteredText(commands, tag.salePrice, x + width / 2, y + 168, pageHeight, priceFontSize(tag.salePrice), "F2", width - 24);

  drawCenteredText(commands, tag.savings, x + 70, y + height - 20, pageHeight, 13, "F2", 42);
  drawText(commands, "Sale Ends", x + width - 50, y + height - 31, pageHeight, 7, "F2", "0 0 0 rg");
  drawText(commands, tag.endDate, x + width - 50, y + height - 17, pageHeight, 8, "F2", "0 0 0 rg");
}

function priceFontSize(value) {
  const length = String(value || "").length;
  if (length > 7) return 30;
  if (length > 5) return 34;
  return 40;
}

function fillRect(commands, x, topY, width, height, pageHeight, color) {
  const y = pageHeight - topY - height;
  commands.push(`${color} ${roundPdf(x)} ${roundPdf(y)} ${roundPdf(width)} ${roundPdf(height)} re f`);
}

function drawText(commands, text, x, topY, pageHeight, size, fontName, color = "0 0 0 rg") {
  if (!text) return;
  const baseline = pageHeight - topY;
  commands.push(`${color} BT /${fontName} ${size} Tf 1 0 0 1 ${roundPdf(x)} ${roundPdf(baseline)} Tm (${escapePdfText(text)}) Tj ET`);
}

function drawRightText(commands, text, rightX, topY, pageHeight, size, fontName) {
  if (!text) return;
  const width = estimatePdfTextWidth(text, size);
  drawText(commands, text, rightX - width, topY, pageHeight, size, fontName);
}

function drawCenteredText(commands, text, centerX, topY, pageHeight, size, fontName, maxWidth) {
  if (!text) return;
  const fitted = fitPdfText(text, size, maxWidth);
  const width = estimatePdfTextWidth(fitted, size);
  drawText(commands, fitted, centerX - width / 2, topY, pageHeight, size, fontName);
}

function fitPdfText(text, size, maxWidth) {
  let output = String(text);
  while (output.length > 1 && estimatePdfTextWidth(output, size) > maxWidth) {
    output = output.slice(0, -1);
  }
  return output;
}

function estimatePdfTextWidth(text, size) {
  return String(text).length * size * 0.56;
}

function buildPdf(pageWidth, pageHeight, content) {
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(pdf.length);
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach((offset) => {
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  });
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  const bytes = new Uint8Array(pdf.length);
  for (let i = 0; i < pdf.length; i += 1) {
    bytes[i] = pdf.charCodeAt(i) & 0xff;
  }
  return bytes;
}

function escapePdfText(value) {
  return String(value)
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)");
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function roundPdf(value) {
  return Number(value).toFixed(3).replace(/\.?0+$/, "");
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  state.tags[state.activeIndex] = currentFormData();
  advance();
  clearForm();
  renderSheet();
  updateStatus();
  save();
});

document.querySelector("#skipButton").addEventListener("click", () => {
  advance();
  renderSheet();
  updateStatus();
  save();
});

undoButton.addEventListener("click", () => {
  const previous = Math.max(0, state.activeIndex - 1);
  state.activeIndex = previous;
  if (state.tags[previous]) loadTagIntoForm(state.tags[previous]);
  renderSheet();
  updateStatus();
  save();
});

document.querySelector("#printButton").addEventListener("click", () => window.print());
document.querySelector("#pdfButton").addEventListener("click", exportPdf);
document.querySelector("#clearButton").addEventListener("click", () => {
  if (!confirm("Clear all 12 sale tags?")) return;
  state.tags = Array.from({ length: TOTAL_TAGS }, () => null);
  state.activeIndex = 0;
  clearForm();
  renderSheet();
  updateStatus();
  save();
});

init();
