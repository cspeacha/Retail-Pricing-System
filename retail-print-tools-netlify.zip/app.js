const tools = {
  "shelf-tags": {
    title: "Shelf Tags",
    url: "shelf-tags/index.html"
  },
  "sale-tags": {
    title: "Sale Tags",
    url: "sale-tags/index.html"
  },
  "signs": {
    title: "Signs",
    url: "signs/index.html"
  }
};

const frame = document.querySelector("#toolFrame");
const tabButtons = [...document.querySelectorAll("[data-tool]")];

function selectTool(toolId) {
  const tool = tools[toolId] || tools["shelf-tags"];

  tabButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.tool === toolId);
  });

  frame.src = tool.url;
  frame.title = tool.title;
  document.title = `${tool.title} | Retail Print Tools`;
}

tabButtons.forEach((button) => {
  button.addEventListener("click", () => selectTool(button.dataset.tool));
});
