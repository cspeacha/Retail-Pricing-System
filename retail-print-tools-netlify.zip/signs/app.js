const fields = {
  size: document.querySelectorAll('input[name="signSize"]'),
  signType: document.querySelector("#signType"),
  product: document.querySelector("#product"),
  brand: document.querySelector("#brand"),
  price: document.querySelector("#price"),
  savings: document.querySelector("#savings"),
  details: document.querySelector("#details"),
  endDate: document.querySelector("#endDate"),
  additionalInfo: document.querySelector("#additionalInfo")
};

const preview = document.querySelector("#signPreview");
const sizeLabel = document.querySelector("#sizeLabel");
const previewProduct = document.querySelector("#previewProduct");
const previewBrand = document.querySelector("#previewBrand");
const previewPrice = document.querySelector("#previewPrice");
const previewSavings = document.querySelector("#previewSavings");
const previewDetails = document.querySelector("#previewDetails");
const previewEndDate = document.querySelector("#previewEndDate");
const previewAdditionalInfo = document.querySelector("#previewAdditionalInfo");
const batchList = document.querySelector("#batchList");
const batchCount = document.querySelector("#batchCount");
const printPageSizeStyle = document.createElement("style");
const SIGN_TYPES = {
  "edlp": { label: "EDLP", order: 1 },
  "ad-sale": { label: "Ad Sale", order: 2 },
  "deal-price": { label: "Deal Price", order: 3 },
  "max-card": { label: "Max Card", order: 4 }
};
let batchSigns = [];

printPageSizeStyle.id = "printPageSize";
document.head.appendChild(printPageSizeStyle);

function selectedSize() {
  return [...fields.size].find((field) => field.checked)?.value || "small";
}

function cleanPrice(value) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  return trimmed.replace(/^\$/, "");
}

function cleanSavings(value) {
  return value.trim().replace(/^save\s*/i, "");
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function updatePreview() {
  const size = selectedSize();
  const signType = fields.signType.value;
  const signTypeLabel = SIGN_TYPES[signType].label;
  const isEdlp = signType === "edlp";

  preview.className = `sign-preview ${size === "large" ? "large-sign" : "small-sign"} ${isEdlp ? "edlp-sign" : ""}`;
  document.body.classList.toggle("edlp-selected", isEdlp);
  sizeLabel.textContent = `${size === "large" ? "Large" : "Small"} ${signTypeLabel} sign`;

  previewProduct.textContent = fields.product.value.trim();
  previewBrand.textContent = fields.brand.value.trim();
  previewPrice.textContent = cleanPrice(fields.price.value);
  previewSavings.textContent = cleanSavings(fields.savings.value);
  previewDetails.textContent = fields.details.value.trim();
  previewEndDate.textContent = fields.endDate.value.trim();
  previewAdditionalInfo.textContent = fields.additionalInfo.value.trim();
}

function preparePrintPageSize() {
  const size = selectedSize();
  const signWidth = size === "large" ? "11in" : "6.5in";
  const signHeight = size === "large" ? "7in" : "3.63in";
  const pageWidth = size === "large" ? "7in" : "3.63in";
  const pageHeight = size === "large" ? "11in" : "6.5in";

  printPageSizeStyle.textContent = `
    @media print {
      @page {
        size: ${pageWidth} ${pageHeight};
        margin: 0;
      }

      html,
      body {
        width: ${pageWidth};
        height: ${pageHeight};
        overflow: hidden;
      }

      .sign-preview {
        position: absolute;
        top: 0;
        left: ${pageWidth};
        width: ${signWidth};
        height: ${signHeight};
        transform: rotate(90deg);
        transform-origin: top left;
      }

      .large-art,
      .small-art {
        display: none !important;
      }
    }
  `;
}

function currentSignData() {
  return {
    id: Date.now() + Math.random(),
    size: selectedSize(),
    signType: fields.signType.value,
    brand: fields.brand.value.trim(),
    variety: fields.product.value.trim(),
    price: cleanPrice(fields.price.value),
    savings: cleanSavings(fields.savings.value),
    details: fields.details.value.trim(),
    endDate: fields.endDate.value.trim(),
    additionalInfo: fields.additionalInfo.value.trim()
  };
}

async function exportWordDoc() {
  const data = currentSignData();
  const isLarge = data.size === "large";
  const pageWidth = isLarge ? 11 : 6.5;
  const pageHeight = isLarge ? 7 : 3.63;
  const layout = isLarge ? largeWordLayout() : smallWordLayout();
  const mhtml = await buildImageWordDoc(data, pageWidth, pageHeight, layout);
  const blob = new Blob([mhtml], { type: "application/msword;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = isLarge ? "large-sign-landscape-image.doc" : "small-sign-landscape-image.doc";
  link.click();
  URL.revokeObjectURL(url);
}

async function exportBatchDoc() {
  if (!batchSigns.length) {
    alert("Add at least one sign to the batch first.");
    return;
  }

  const firstSize = batchSigns[0].size;
  if (batchSigns.some((sign) => sign.size !== firstSize)) {
    alert("Please keep one paper size per batch. Export 3x5 signs and 7x11 signs separately.");
    return;
  }

  const isLarge = firstSize === "large";
  const pageWidth = isLarge ? 11 : 6.5;
  const pageHeight = isLarge ? 7 : 3.63;
  const layout = isLarge ? largeWordLayout() : smallWordLayout();
  const orderedSigns = orderedBatchSigns();
  const mhtml = await buildImageWordDoc(orderedSigns, pageWidth, pageHeight, layout);
  const blob = new Blob([mhtml], { type: "application/msword;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = isLarge ? "large-sign-batch-image.doc" : "small-sign-batch-image.doc";
  link.click();
  URL.revokeObjectURL(url);
}

function addCurrentToBatch() {
  const sign = currentSignData();

  if (batchSigns.length && batchSigns[0].size !== sign.size) {
    alert("This batch already has a different paper size. Export or clear it before adding this sign.");
    return;
  }

  batchSigns.push(sign);
  renderBatchList();
  clearForm();
}

function orderedBatchSigns() {
  return [...batchSigns].sort((a, b) => {
    const typeDiff = SIGN_TYPES[a.signType].order - SIGN_TYPES[b.signType].order;
    return typeDiff || batchSigns.indexOf(a) - batchSigns.indexOf(b);
  });
}

function renderBatchList() {
  const orderedSigns = orderedBatchSigns();
  batchCount.textContent = `${batchSigns.length} ${batchSigns.length === 1 ? "sign" : "signs"}`;
  batchList.innerHTML = orderedSigns
    .map((sign) => {
      const type = SIGN_TYPES[sign.signType].label;
      const size = sign.size === "large" ? "7x11" : "3x5";
      return `<li>
        <span><strong>${escapeHtml(type)}</strong> ${escapeHtml(sign.brand || "Untitled")} ${escapeHtml(sign.price ? "$" + sign.price : "")}</span>
        <small>${escapeHtml(size)}</small>
        <button type="button" data-remove-id="${sign.id}">Remove</button>
      </li>`;
    })
    .join("");
}

function removeBatchSign(id) {
  batchSigns = batchSigns.filter((sign) => String(sign.id) !== String(id));
  renderBatchList();
}

function clearBatch() {
  batchSigns = [];
  renderBatchList();
}

function smallWordLayout() {
  return {
    wordShiftX: 0.25,
    bannerHeight: 1,
    bannerColumns: "0.75in 1fr 1.43in",
    bannerGap: 0.08,
    bannerPaddingY: 0.07,
    bannerPaddingX: 0.16,
    maxTopSize: 0.31,
    maxMainSize: 0.7,
    maxStroke: 0.032,
    pointsSize: 0.16,
    pointsBorder: 0.035,
    priceTop: 1.32,
    priceLeft: 1.8,
    priceRight: 0.72,
    priceHeight: 1.05,
    dollarSize: 0.42,
    dollarLeftOffset: 0.08,
    priceSize: 1,
    brandTop: 2.34,
    brandLeft: 1.7,
    brandRight: 1.3,
    brandSize: 0.361,
    varietyTop: 2.72,
    varietyLeft: 1.62,
    varietyRight: 1.18,
    varietySize: 0.25,
    detailsTop: 2.98,
    detailsLeft: 1.58,
    detailsRight: 0.98,
    detailsSize: 0.25,
    savingsTop: 2.58,
    savingsRight: 0.58,
    savingsWidth: 0.9,
    savingsSize: 0.389,
    savingsLabelSize: 0.28,
    dateTop: 2.88,
    dateLeft: 0.9,
    dateWidth: 1.55,
    dateSize: 0.25,
    dateLabelSize: 0.18,
    additionalInfoTop: 1.5,
    additionalInfoLeft: 0.7,
    additionalInfoWidth: 1.18,
    additionalInfoHeight: 0.86,
    additionalInfoSize: 0.2
  };
}

function largeWordLayout() {
  return {
    wordShiftX: 0.3,
    bannerHeight: 1.86,
    bannerColumns: "1.28in 1fr 2.42in",
    bannerGap: 0.13,
    bannerPaddingY: 0.13,
    bannerPaddingX: 0.26,
    maxTopSize: 0.53,
    maxMainSize: 1.19,
    maxStroke: 0.055,
    pointsSize: 0.29,
    pointsBorder: 0.06,
    priceTop: 2.42,
    priceLeft: 3.04,
    priceRight: 1.21,
    priceHeight: 2.45,
    dollarSize: 0.75,
    dollarLeftOffset: 0.2,
    priceSize: 2.222,
    brandTop: 4.52,
    brandLeft: 2.86,
    brandRight: 2.2,
    brandSize: 0.667,
    varietyTop: 5.26,
    varietyLeft: 2.75,
    varietyRight: 1.98,
    varietySize: 0.333,
    detailsTop: 5.78,
    detailsLeft: 2.68,
    detailsRight: 1.65,
    detailsSize: 0.333,
    savingsTop: 4.57,
    savingsRight: 0.85,
    savingsWidth: 1.41,
    savingsSize: 0.667,
    savingsLabelSize: 0.46,
    dateTop: 5.92,
    dateLeft: 0.4,
    dateWidth: 2.55,
    dateSize: 0.389,
    dateLabelSize: 0.28,
    additionalInfoTop: 2.55,
    additionalInfoLeft: 0.42,
    additionalInfoWidth: 2.35,
    additionalInfoHeight: 1.45,
    additionalInfoSize: 0.36
  };
}

async function buildImageWordDoc(signData, pageWidth, pageHeight, l) {
  const signs = Array.isArray(signData) ? signData : [signData];
  const shiftX = l.wordShiftX || 0;
  const priceWidth = pageWidth - l.priceLeft - l.priceRight;
  const brandHeight = Math.max(0.7, l.brandSize * 1.4);
  const varietyHeight = Math.max(0.6, l.varietySize * 1.4);
  const detailsHeight = Math.max(0.6, l.detailsSize * 1.4);
  const savingsHeight = Math.max(1, (l.savingsLabelSize + l.savingsSize) * 1.6);
  const dateHeight = Math.max(0.5, (l.dateLabelSize + l.dateSize) * 1.45);
  const dollarBox = Math.max(0.45, l.dollarSize * 1.15);
  const pageSpecs = signs.map((data) => {
    const specs = [
        {
        left: l.priceLeft + shiftX,
        top: l.priceTop,
        width: priceWidth,
        height: l.priceHeight,
        lines: [data.price],
        sizes: l.priceSize,
        font: "Impact"
      },
      {
        left: l.priceLeft + shiftX + (l.dollarLeftOffset || 0),
        top: l.priceTop + 0.03,
        width: dollarBox,
        height: dollarBox,
        lines: ["$"],
        sizes: l.dollarSize,
        font: "Impact",
        align: "left"
      },
      {
        left: l.brandLeft + shiftX,
        top: l.brandTop,
        width: pageWidth - l.brandLeft - l.brandRight,
        height: brandHeight,
        lines: [data.brand],
        sizes: l.brandSize,
        font: "Impact"
      },
      {
        left: l.varietyLeft + shiftX,
        top: l.varietyTop,
        width: pageWidth - l.varietyLeft - l.varietyRight,
        height: varietyHeight,
        lines: [data.variety],
        sizes: l.varietySize,
        font: "Impact"
      },
      {
        left: l.detailsLeft + shiftX,
        top: l.detailsTop,
        width: pageWidth - l.detailsLeft - l.detailsRight,
        height: detailsHeight,
        lines: [data.details],
        sizes: l.detailsSize,
        font: "Impact"
      }
    ];

    if (data.signType !== "edlp") {
      specs.push({
        left: pageWidth - l.savingsRight - l.savingsWidth + shiftX,
        top: l.savingsTop,
        width: l.savingsWidth,
        height: savingsHeight,
        lines: ["SAVE", data.savings],
        sizes: [l.savingsLabelSize, l.savingsSize],
        font: "Arial"
      });
      specs.push({
        left: l.dateLeft + shiftX,
        top: l.dateTop,
        width: l.dateWidth,
        height: dateHeight,
        lines: ["AD ENDS", data.endDate],
        sizes: [l.dateLabelSize, l.dateSize],
        font: "Arial"
      });
      specs.push({
        left: l.additionalInfoLeft + shiftX,
        top: l.additionalInfoTop,
        width: l.additionalInfoWidth,
        height: l.additionalInfoHeight,
        lines: [data.additionalInfo],
        sizes: l.additionalInfoSize,
        font: "Arial",
        wrap: true,
        maxLines: 3
      });
    }

    return specs;
  });
  const pages = await Promise.all(
    pageSpecs.map(async (specs, pageIndex) => [{
      name: `sign-page-${pageIndex + 1}.png`,
      left: 0,
      top: 0,
      width: pageWidth,
      height: pageHeight,
      base64: await renderSignPagePng(specs, pageWidth, pageHeight)
    }])
  );
  return buildMhtmlWordDoc(pageWidth, pageHeight, pages);
}

function buildMhtmlWordDoc(pageWidth, pageHeight, pages) {
  const boundary = "----=_SignMakerImageExport";
  const allImages = pages.flat();
  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:v="urn:schemas-microsoft-com:vml">
<head>
<meta charset="utf-8">
<!--[if gte mso 9]>
<xml>
  <w:WordDocument>
    <w:View>Print</w:View>
    <w:Zoom>100</w:Zoom>
  </w:WordDocument>
</xml>
<![endif]-->
<style>
@page Section1 {
  size: ${pageWidth}in ${pageHeight}in;
  mso-page-orientation: landscape;
  margin: 0;
}
html,
body {
  margin: 0;
  padding: 0;
}
.Section1 {
  page: Section1;
  width: ${pageWidth}in;
  height: ${pageHeight}in;
  overflow: hidden;
  margin: 0;
  padding: 0;
}
.sign-page-image {
  display: block;
  width: ${pageWidth}in;
  height: ${pageHeight}in;
  margin: 0;
  padding: 0;
  border: 0;
}
.page-break-after {
  page-break-after: always;
}
</style>
</head>
<body>
${pages.map((images, index) => `<div class="Section1${index < pages.length - 1 ? " page-break-after" : ""}">
  <img class="sign-page-image" src="${images[0].name}" width="${Math.round(pageWidth * 96)}" height="${Math.round(pageHeight * 96)}">
</div>`).join("\n")}
</body>
</html>`;
  const imageParts = allImages
    .map((image) => [
      `--${boundary}`,
      "Content-Type: image/png",
      "Content-Transfer-Encoding: base64",
      `Content-Location: ${image.name}`,
      "",
      chunkBase64(image.base64)
    ].join("\r\n"))
    .join("\r\n");

  return [
    "MIME-Version: 1.0",
    `Content-Type: multipart/related; boundary="${boundary}"`,
    "",
    `--${boundary}`,
    'Content-Type: text/html; charset="utf-8"',
    "Content-Location: sign.htm",
    "",
    html,
    imageParts,
    `--${boundary}--`,
    ""
  ].join("\r\n");
}

function renderTextPng(spec) {
  const dpi = 300;
  const canvas = document.createElement("canvas");
  const width = Math.max(1, Math.round(spec.width * dpi));
  const height = Math.max(1, Math.round(spec.height * dpi));
  const lines = spec.lines.map((line) => String(line || "").toUpperCase());
  const sizes = Array.isArray(spec.sizes) ? spec.sizes : lines.map(() => spec.sizes);
  const lineHeights = sizes.map((size) => size * dpi * 1.03);
  const totalHeight = lineHeights.reduce((sum, lineHeight) => sum + lineHeight, 0);
  const align = spec.align || "center";
  const padding = Math.round(0.02 * dpi);
  let y = (height - totalHeight) / 2;

  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d");
  context.clearRect(0, 0, width, height);
  context.fillStyle = spec.color || "#000000";
  context.textAlign = align;
  context.textBaseline = "middle";

  lines.forEach((line, index) => {
    const fontPx = sizes[index] * dpi;
    context.font = `900 ${fontPx}px ${spec.font}, Arial, sans-serif`;
    const x = align === "left" ? padding : width / 2;
    const lineCenter = y + lineHeights[index] / 2;
    context.fillText(line, x, lineCenter, width - (padding * 2));
    y += lineHeights[index];
  });

  return Promise.resolve(canvas.toDataURL("image/png").split(",")[1]);
}

function renderSignPagePng(specs, pageWidth, pageHeight) {
  const dpi = 300;
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");

  canvas.width = Math.round(pageWidth * dpi);
  canvas.height = Math.round(pageHeight * dpi);
  context.clearRect(0, 0, canvas.width, canvas.height);

  specs.forEach((spec) => {
    drawTextBlock(context, spec, dpi);
  });

  return Promise.resolve(canvas.toDataURL("image/png").split(",")[1]);
}

function drawTextBlock(context, spec, dpi) {
  const left = Math.round(spec.left * dpi);
  const top = Math.round(spec.top * dpi);
  const width = Math.max(1, Math.round(spec.width * dpi));
  const height = Math.max(1, Math.round(spec.height * dpi));
  const baseSize = Array.isArray(spec.sizes) ? spec.sizes[0] : spec.sizes;
  const baseFontPx = baseSize * dpi;
  context.font = `900 ${baseFontPx}px ${spec.font}, Arial, sans-serif`;
  const rawLines = spec.lines.map((line) => String(line || "").toUpperCase());
  const lines = spec.wrap
    ? wrapCanvasText(context, rawLines.join(" "), width - (Math.round(0.02 * dpi) * 2), spec.maxLines || 3)
    : rawLines;
  const sizes = Array.isArray(spec.sizes) && !spec.wrap ? spec.sizes : lines.map(() => baseSize);
  const lineHeights = sizes.map((size) => size * dpi * 1.03);
  const totalHeight = lineHeights.reduce((sum, lineHeight) => sum + lineHeight, 0);
  const align = spec.align || "center";
  const padding = Math.round(0.02 * dpi);
  let y = top + (height - totalHeight) / 2;

  context.save();
  context.beginPath();
  context.rect(left, top, width, height);
  context.clip();
  context.fillStyle = spec.color || "#000000";
  context.textAlign = align;
  context.textBaseline = "middle";

  lines.forEach((line, index) => {
    const fontPx = sizes[index] * dpi;
    context.font = `900 ${fontPx}px ${spec.font}, Arial, sans-serif`;
    const x = align === "left" ? left + padding : left + (width / 2);
    const lineCenter = y + lineHeights[index] / 2;
    context.fillText(line, x, lineCenter, width - (padding * 2));
    y += lineHeights[index];
  });

  context.restore();
}

function wrapCanvasText(context, text, maxWidth, maxLines) {
  const words = text.split(/\s+/).filter(Boolean);
  const lines = [];
  let line = "";

  words.forEach((word) => {
    const nextLine = line ? `${line} ${word}` : word;
    if (context.measureText(nextLine).width <= maxWidth || !line) {
      line = nextLine;
      return;
    }

    lines.push(line);
    line = word;
  });

  if (line) {
    lines.push(line);
  }

  if (lines.length <= maxLines) {
    return lines;
  }

  const trimmed = lines.slice(0, maxLines);
  trimmed[maxLines - 1] = `${trimmed[maxLines - 1]} ${lines.slice(maxLines).join(" ")}`.trim();
  return trimmed;
}

function chunkBase64(value) {
  return value.match(/.{1,76}/g).join("\r\n");
}

function buildWordHtml(data, pageWidth, pageHeight, l) {
  const priceWidth = pageWidth - l.priceLeft - l.priceRight;
  const banner = bannerMetrics(pageWidth, l);
  const margin = "1.2in .4in .5in .4in";
  const shiftX = l.wordShiftX || 0;
  const brandHeight = Math.max(0.7, l.brandSize * 1.4);
  const varietyHeight = Math.max(0.6, l.varietySize * 1.4);
  const detailsHeight = Math.max(0.6, l.detailsSize * 1.4);
  const savingsHeight = Math.max(1, (l.savingsLabelSize + l.savingsSize) * 1.6);
  const dateHeight = Math.max(0.5, l.dateSize * 1.5);
  const dollarBox = Math.max(0.45, l.dollarSize * 1.15);

  return `<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:v="urn:schemas-microsoft-com:vml">
<head>
<meta charset="utf-8">
<!--[if gte mso 9]>
<xml>
  <w:WordDocument>
    <w:View>Print</w:View>
    <w:Zoom>100</w:Zoom>
  </w:WordDocument>
</xml>
<![endif]-->
<style>
v\\:* { behavior:url(#default#VML); }
@page Section1 {
  size: ${pageWidth}in ${pageHeight}in;
  mso-page-orientation: landscape;
  margin: ${margin};
}
body {
  margin: 0;
  padding: 0;
  width: ${pageWidth}in;
  height: ${pageHeight}in;
}
div.Section1 {
  page: Section1;
  position: relative;
  width: ${pageWidth}in;
  height: ${pageHeight}in;
  overflow: hidden;
  background: #fffefa;
  color: #000;
}
</style>
</head>
<body>
<div class="Section1">
  ${vRect(0, 0, pageWidth, l.bannerHeight, "#000000", "")}
  ${vText(banner.leftX, l.bannerPaddingY, banner.leftW, l.bannerHeight - (l.bannerPaddingY * 2), wordLines(["SAVE", "BIG", "WITH"], l.maxTopSize, "Impact", "center", "#ffffff"))}
  ${vText(banner.centerX, l.bannerPaddingY, banner.centerW, l.bannerHeight - (l.bannerPaddingY * 2), wordLine("MAX PLUS!", l.maxMainSize, "Impact", "center", "#777777"))}
  ${vText(banner.rightX, l.bannerPaddingY, banner.rightW, l.bannerHeight - (l.bannerPaddingY * 2), wordLines(["EARN POINTS", "WITH", "EVERY", "PURCHASE"], l.pointsSize, "Arial", "center", "#ffffff"))}
  ${vText(l.priceLeft + shiftX, l.priceTop, priceWidth, l.priceHeight, wordLine(data.price, l.priceSize, "Impact", "center"))}
  ${vText(l.priceLeft + shiftX, l.priceTop + 0.03, dollarBox, dollarBox, wordLine("$", l.dollarSize, "Impact", "left"))}
  ${vText(l.brandLeft + shiftX, l.brandTop, pageWidth - l.brandLeft - l.brandRight, brandHeight, wordLine(data.brand, l.brandSize, "Impact", "center"))}
  ${vText(l.varietyLeft + shiftX, l.varietyTop, pageWidth - l.varietyLeft - l.varietyRight, varietyHeight, wordLine(data.variety, l.varietySize, "Impact", "center"))}
  ${vText(l.detailsLeft + shiftX, l.detailsTop, pageWidth - l.detailsLeft - l.detailsRight, detailsHeight, wordLine(data.details, l.detailsSize, "Impact", "center"))}
  ${vText(pageWidth - l.savingsRight - l.savingsWidth + shiftX, l.savingsTop, l.savingsWidth, savingsHeight, wordLines(["SAVE", data.savings], [l.savingsLabelSize, l.savingsSize], "Arial", "center"))}
  ${vText(l.dateLeft + shiftX, l.dateTop, l.dateWidth, dateHeight, wordLine(data.endDate, l.dateSize, "Arial", "center"))}
</div>
</body>
</html>`;
}

function bannerMetrics(pageWidth, l) {
  const parts = l.bannerColumns.split(" ");
  const leftW = parseFloat(parts[0]);
  const rightW = parseFloat(parts[2]);
  const centerX = l.bannerPaddingX + leftW + l.bannerGap;
  const rightX = pageWidth - l.bannerPaddingX - rightW;
  return {
    leftX: l.bannerPaddingX,
    leftW,
    centerX,
    centerW: rightX - centerX - l.bannerGap,
    rightX,
    rightW
  };
}

function vRect(left, top, width, height, fillColor, content) {
  return `<v:rect fillcolor="${fillColor}" stroked="f" style="position:absolute;left:${left}in;top:${top}in;width:${width}in;height:${height}in;mso-position-horizontal-relative:page;mso-position-vertical-relative:page;z-index:1;"><v:textbox inset="0,0,0,0">${content}</v:textbox></v:rect>`;
}

function vText(left, top, width, height, content) {
  return `<v:shape type="#_x0000_t202" filled="f" stroked="f" style="position:absolute;left:${left}in;top:${top}in;width:${width}in;height:${height}in;mso-position-horizontal-relative:page;mso-position-vertical-relative:page;z-index:2;v-text-anchor:middle;"><v:textbox inset="0,0,0,0" style="mso-fit-shape-to-text:false"><w:txbxContent>${content}</w:txbxContent></v:textbox></v:shape>`;
}

function toPt(inches) {
  return Number(inches * 72).toFixed(1);
}

function wordLine(value, size, fontFamily, align = "center", color = "#000000") {
  const fontSize = Array.isArray(size) ? size[0] : size;
  return wordParagraph(value, fontSize, fontFamily, align, color);
}

function wordLines(values, sizes, fontFamily, align = "center", color = "#000000") {
  return values
    .map((value, index) => wordParagraph(value, Array.isArray(sizes) ? sizes[index] : sizes, fontFamily, align, color))
    .join("");
}

function wordParagraph(value, size, fontFamily, align, color) {
  const points = toPt(size);
  const escaped = escapeHtml(value).toUpperCase();
  return `<p class="MsoNormal" align="${align}" style="margin:0;text-align:${align};line-height:1;mso-line-height-rule:exactly;"><b><span style="font-family:${fontFamily};mso-bidi-font-family:${fontFamily};font-size:${points}pt;mso-bidi-font-size:${points}pt;color:${color};">${escaped}</span></b></p>`;
}

function clearForm() {
  fields.product.value = "";
  fields.brand.value = "";
  fields.price.value = "";
  fields.savings.value = "";
  fields.details.value = "";
  fields.endDate.value = "";
  fields.additionalInfo.value = "";
  fields.product.focus();
  updatePreview();
}

document.querySelector("#signForm").addEventListener("input", updatePreview);
fields.signType.addEventListener("change", clearForm);
document.querySelector("#addBatchButton").addEventListener("click", addCurrentToBatch);
document.querySelector("#wordButton").addEventListener("click", exportWordDoc);
document.querySelector("#exportBatchButton").addEventListener("click", exportBatchDoc);
document.querySelector("#printButton")?.addEventListener("click", () => {
    preparePrintPageSize();
    window.print();
  });
document.querySelector("#clearButton").addEventListener("click", clearForm);
document.querySelector("#clearBatchButton").addEventListener("click", clearBatch);
batchList.addEventListener("click", (event) => {
  const removeButton = event.target.closest("[data-remove-id]");
  if (removeButton) {
    removeBatchSign(removeButton.dataset.removeId);
  }
});

updatePreview();
renderBatchList();
