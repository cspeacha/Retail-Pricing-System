const TOTAL_LABELS = 32;

const CODE_128_PATTERNS = [
  "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312",
  "132212", "221213", "221312", "231212", "112232", "122132", "122231", "113222",
  "123122", "123221", "223211", "221132", "221231", "213212", "223112", "312131",
  "311222", "321122", "321221", "312212", "322112", "322211", "212123", "212321",
  "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313",
  "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121",
  "313121", "211331", "231131", "213113", "213311", "213131", "311123", "311321",
  "331121", "312113", "312311", "332111", "314111", "221411", "431111", "111224",
  "111422", "121124", "121421", "141122", "141221", "112214", "112412", "122114",
  "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111",
  "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112",
  "421211", "212141", "214121", "412121", "111143", "111341", "131141", "114113",
  "114311", "411113", "411311", "113141", "114131", "311141", "411131", "211412",
  "211214", "211232", "2331112"
];

const state = {
  labels: Array.from({ length: TOTAL_LABELS }, () => null),
  activeIndex: 0
};

const fields = {
  description: document.querySelector("#description"),
  price: document.querySelector("#price"),
  orderNumber: document.querySelector("#orderNumber"),
  upc: document.querySelector("#upc"),
  barcodeValue: document.querySelector("#barcodeValue")
};

const sheet = document.querySelector("#labelSheet");
const form = document.querySelector("#tagForm");
const statusText = document.querySelector("#statusText");
const activeLabelText = document.querySelector("#activeLabelText");
const filledCount = document.querySelector("#filledCount");
const pageNotice = document.querySelector("#pageNotice");
const addButton = document.querySelector("#addButton");
const undoButton = document.querySelector("#undoButton");

function init() {
  const saved = localStorage.getItem("shelf-tag-maker-state");
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed.labels) && parsed.labels.length === TOTAL_LABELS) {
        state.labels = parsed.labels;
        state.activeIndex = Math.min(parsed.activeIndex || firstOpenIndex(), TOTAL_LABELS - 1);
      }
    } catch {
      localStorage.removeItem("shelf-tag-maker-state");
    }
  }

  renderSheet();
  updateStatus();
  fields.description.focus();
}

function save() {
  localStorage.setItem("shelf-tag-maker-state", JSON.stringify(state));
}

function firstOpenIndex() {
  const open = state.labels.findIndex((label) => !label);
  return open === -1 ? TOTAL_LABELS - 1 : open;
}

function cleanPrice(value) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (trimmed.startsWith("$")) return trimmed;
  return `$${trimmed}`;
}

function currentFormData() {
  const upc = fields.upc.value.trim();
  const orderNumber = fields.orderNumber.value.trim();
  return {
    description: fields.description.value.trim(),
    price: cleanPrice(fields.price.value),
    orderNumber,
    upc,
    barcodeValue: fields.barcodeValue.value.trim() || orderNumber
  };
}

function clearForm() {
  form.reset();
  fields.description.focus();
}

function advance() {
  const open = state.labels.findIndex((label, index) => !label && index > state.activeIndex);
  state.activeIndex = open === -1 ? firstOpenIndex() : open;
}

function renderSheet() {
  sheet.innerHTML = "";
  state.labels.forEach((label, index) => {
    const item = document.createElement("button");
    item.type = "button";
    item.className = `label ${label ? "" : "empty"} ${index === state.activeIndex ? "active" : ""}`;
    item.setAttribute("aria-label", `Label ${index + 1}`);
    item.addEventListener("click", () => {
      state.activeIndex = index;
      if (state.labels[index]) loadLabelIntoForm(state.labels[index]);
      renderSheet();
      updateStatus();
      save();
    });

    if (!label) {
      item.innerHTML = `<div class="placeholder">${index + 1}</div>`;
    } else {
      item.appendChild(labelContent(label));
    }

    sheet.appendChild(item);
  });
}

function labelContent(label) {
  const wrap = document.createElement("div");
  wrap.className = "tag-body";
  const barcode = createBarcodeSvg(label.barcodeValue);
  wrap.innerHTML = `
    <div class="tag-cell description-cell">
      <div class="description"></div>
    </div>
    <div class="tag-cell order-cell">
      <div class="field-value order-number"></div>
    </div>
    <div class="tag-cell price-cell">
      <div class="price"></div>
    </div>
    <div class="tag-cell upc-cell">
      <div class="field-value upc"></div>
    </div>
    <div class="tag-cell barcode-cell">
      <div class="barcode"></div>
    </div>
  `;
  wrap.querySelector(".description").textContent = label.description;
  wrap.querySelector(".price").textContent = label.price;
  wrap.querySelector(".order-number").textContent = label.orderNumber;
  wrap.querySelector(".upc").textContent = label.upc;
  wrap.querySelector(".barcode").appendChild(barcode);
  return wrap;
}

function loadLabelIntoForm(label) {
  fields.description.value = label.description;
  fields.price.value = label.price.replace(/^\$/, "");
  fields.orderNumber.value = label.orderNumber;
  fields.upc.value = label.upc;
  fields.barcodeValue.value = label.barcodeValue;
}

function updateStatus() {
  const count = state.labels.filter(Boolean).length;
  filledCount.textContent = count;
  undoButton.disabled = state.activeIndex === 0 && !state.labels[0];
  pageNotice.hidden = count !== TOTAL_LABELS;
  addButton.textContent = state.labels[state.activeIndex] ? "Update Tag" : "Add Tag";

  if (count === TOTAL_LABELS) {
    statusText.textContent = "Page filled. Ready for printing.";
    activeLabelText.textContent = "All 32 labels are filled";
  } else {
    statusText.textContent = `Label ${state.activeIndex + 1} of ${TOTAL_LABELS} is ready.`;
    activeLabelText.textContent = `Filling label ${state.activeIndex + 1}`;
  }
}

function createBarcodeSvg(value) {
  const safeValue = value || " ";
  const codes = [104];
  for (const char of safeValue) {
    const code = char.charCodeAt(0) - 32;
    if (code < 0 || code > 95) {
      throw new Error("Code 128 barcode supports standard printable keyboard characters.");
    }
    codes.push(code);
  }

  let checksum = codes[0];
  for (let index = 1; index < codes.length; index += 1) {
    checksum += codes[index] * index;
  }
  codes.push(checksum % 103, 106);

  const moduleWidth = 1.35;
  const height = 44;
  let x = 0;
  const bars = [];

  codes.forEach((code) => {
    const pattern = CODE_128_PATTERNS[code];
    for (let i = 0; i < pattern.length; i += 1) {
      const width = Number(pattern[i]) * moduleWidth;
      if (i % 2 === 0) {
        bars.push(`<rect x="${x.toFixed(2)}" y="0" width="${width.toFixed(2)}" height="${height}"></rect>`);
      }
      x += width;
    }
  });

  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", `0 0 ${x.toFixed(2)} ${height}`);
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", `Code 128 barcode for ${safeValue}`);
  svg.innerHTML = bars.join("");
  return svg;
}

async function exportXlsx() {
  const workbook = window.TAG_MASTER_TEMPLATE_FILES
    ? await createTemplateXlsxWorkbook(state.labels)
    : createPlainXlsxWorkbook(state.labels);
  const blob = new Blob([workbook], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "shelf-tags.xlsx";
  link.click();
  URL.revokeObjectURL(url);
}

function exportPdf() {
  const pdf = createShelfTagPdf(state.labels);
  const blob = new Blob([pdf], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "shelf-tags.pdf";
  link.click();
  URL.revokeObjectURL(url);
}

function createShelfTagPdf(labels) {
  const pageWidth = 612;
  const pageHeight = 792;
  const rowShiftUp = 15;
  const gridX = [31, 176.43, 317.56, 459.45, 602];
  const gridY = [43.18, 134.44, 225.45, 313.39, 401.4, 489.93, 576.58, 663.4, 749.81]
    .map((value) => value - rowShiftUp);
  const commands = [];

  labels.forEach((label, index) => {
    if (!label) return;
    const row = Math.floor(index / 4);
    const col = index % 4;
    const x = gridX[col];
    const y = gridY[row];
    const width = gridX[col + 1] - x;
    const height = gridY[row + 1] - y;
    drawPdfTag(commands, label, x, y, width, height, pageHeight, col);
  });

  return buildPdf(pageWidth, pageHeight, commands.join("\n"));
}

function drawPdfTag(commands, label, x, y, width, height, pageHeight, col) {
  const orderNumber = label.orderNumber || "";
  const barcodeValue = label.barcodeValue || orderNumber;
  const leftFieldNudge = col === 0 ? -6 : 0;

  drawCenteredText(commands, label.description || "", x + width / 2, y + 20, pageHeight, 11, "F2", width - 12);
  drawText(commands, orderNumber, x + 7 + leftFieldNudge, y + 48, pageHeight, 12, "F2");
  drawCenteredText(commands, label.price || "", x + width * 0.68, y + 61, pageHeight, 18, "F2", width * 0.62);
  drawText(commands, label.upc || "", x + 7 + leftFieldNudge, y + 70, pageHeight, 7, "F2");
  drawPdfBarcode(commands, barcodeValue, x + 10, y + height - 13, width - 20, 7, pageHeight);
}

function drawText(commands, text, x, topY, pageHeight, size, fontName) {
  if (!text) return;
  const baseline = pageHeight - topY;
  commands.push(`BT /${fontName} ${size} Tf 1 0 0 1 ${roundPdf(x)} ${roundPdf(baseline)} Tm (${escapePdfText(text)}) Tj ET`);
}

function drawCenteredText(commands, text, centerX, topY, pageHeight, size, fontName, maxWidth) {
  if (!text) return;
  const fitted = fitPdfText(text, size, maxWidth);
  const textWidth = estimatePdfTextWidth(fitted, size);
  drawText(commands, fitted, centerX - textWidth / 2, topY, pageHeight, size, fontName);
}

function fitPdfText(text, size, maxWidth) {
  let output = String(text);
  while (output.length > 1 && estimatePdfTextWidth(output, size) > maxWidth) {
    output = output.slice(0, -1);
  }
  return output;
}

function estimatePdfTextWidth(text, size) {
  return String(text).length * size * 0.56;
}

function drawPdfBarcode(commands, value, x, topY, width, height, pageHeight) {
  if (!value) return;
  const patterns = code128PatternsForValue(value);
  const quietModules = 12;
  const totalModules = patterns.reduce((total, pattern) => (
    total + [...pattern].reduce((sum, module) => sum + Number(module), 0)
  ), 0);
  const moduleWidth = width / (totalModules + quietModules * 2);
  let cursor = x + quietModules * moduleWidth;
  const y = pageHeight - topY - height;

  commands.push("0 0 0 rg");
  patterns.forEach((pattern) => {
    for (let i = 0; i < pattern.length; i += 1) {
      const barWidth = Number(pattern[i]) * moduleWidth;
      if (i % 2 === 0) {
        commands.push(`${roundPdf(cursor)} ${roundPdf(y)} ${roundPdf(barWidth)} ${roundPdf(height)} re f`);
      }
      cursor += barWidth;
    }
  });
}

function buildPdf(pageWidth, pageHeight, content) {
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(pdf.length);
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach((offset) => {
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  });
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;

  const bytes = new Uint8Array(pdf.length);
  for (let i = 0; i < pdf.length; i += 1) {
    bytes[i] = pdf.charCodeAt(i) & 0xff;
  }
  return bytes;
}

function escapePdfText(value) {
  return String(value)
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)");
}

function roundPdf(value) {
  return Number(value).toFixed(3).replace(/\.?0+$/, "");
}

function createPlainXlsxWorkbook(labels) {
  const headers = ["Label", "Description", "Price", "Order Number", "UPC", "Barcode Value"];
  const rows = labels.map((label, index) => [
    index + 1,
    label?.description || "",
    label?.price || "",
    label?.orderNumber || "",
    label?.upc || "",
    label?.barcodeValue || ""
  ]);
  return createXlsxWorkbook([headers, ...rows]);
}

async function createTemplateXlsxWorkbook(labels) {
  const files = decodeTemplateFiles(window.TAG_MASTER_TEMPLATE_FILES);
  const sheetPath = "xl/worksheets/sheet2.xml";
  const decoder = new TextDecoder();
  const sheetXml = decoder.decode(files[sheetPath]);
  const barcodeImages = await Promise.all(labels.map((label) => {
    const value = label?.barcodeValue || label?.orderNumber || "";
    return value ? createBarcodePngBytes(value) : Promise.resolve(null);
  }));

  files["xl/styles.xml"] = addFinalTagStyles(textFromFile(files["xl/styles.xml"]));
  files["xl/workbook.xml"] = setTemplatePrintArea(textFromFile(files["xl/workbook.xml"]));
  files[sheetPath] = fillTemplateWorksheet(sheetXml, labels);
  addBarcodeImagesToTemplate(files, labels, barcodeImages);
  return zipFiles(files);
}

function decodeTemplateFiles(source) {
  const files = {};
  Object.entries(source).forEach(([name, base64]) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    files[name] = bytes;
  });
  return files;
}

function fillTemplateWorksheet(sheetXml, labels) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(sheetXml, "application/xml");
  const parseError = doc.querySelector("parsererror");
  if (parseError) {
    throw new Error("The Excel template could not be read.");
  }

  enforceShelfTagPrintSettings(doc);

  labels.forEach((label, index) => {
    const rowBlock = Math.floor(index / 4);
    const colBlock = index % 4;
    const row = 2 + rowBlock * 4;
    const leftCol = 1 + colBlock * 2;
    const rightCol = leftCol + 1;

    setCellText(doc, cellRef(leftCol, row), label?.description || "");
    setCellStyle(doc, cellRef(leftCol, row), TEMPLATE_STYLE.description);
    setCellText(doc, cellRef(leftCol, row + 1), label?.orderNumber || "");
    setCellValue(doc, cellRef(rightCol, row + 1), priceNumber(label?.price), label?.price || "");
    setCellStyle(doc, cellRef(rightCol, row + 1), TEMPLATE_STYLE.price);
    setCellText(doc, cellRef(leftCol, row + 2), label?.upc || "");
    setCellStyle(doc, cellRef(leftCol, row + 2), TEMPLATE_STYLE.upc);
    setCellText(doc, cellRef(leftCol, row + 3), "");
    setCellStyle(doc, cellRef(leftCol, row + 3), TEMPLATE_STYLE.barcode);
    setCellText(doc, cellRef(rightCol, row + 3), "");
    setCellStyle(doc, cellRef(rightCol, row + 3), TEMPLATE_STYLE.barcode);
  });

  mergeFullWidthBarcodeRows(doc);
  return new XMLSerializer().serializeToString(doc);
}

function setTemplatePrintArea(workbookXml) {
  return workbookXml.replace(
    /<definedName name="_xlnm\.Print_Area" localSheetId="1">[^<]+<\/definedName>/,
    '<definedName name="_xlnm.Print_Area" localSheetId="1">\'32UP TAGS\'!$A$2:$H$33</definedName>'
  );
}

function enforceShelfTagPrintSettings(doc) {
  const namespace = doc.documentElement.namespaceURI;
  const worksheet = doc.documentElement;

  let printOptions = doc.getElementsByTagNameNS(namespace, "printOptions")[0];
  if (!printOptions) {
    printOptions = doc.createElementNS(namespace, "printOptions");
    worksheet.appendChild(printOptions);
  }
  printOptions.setAttribute("horizontalCentered", "1");

  let pageMargins = doc.getElementsByTagNameNS(namespace, "pageMargins")[0];
  if (!pageMargins) {
    pageMargins = doc.createElementNS(namespace, "pageMargins");
    worksheet.appendChild(pageMargins);
  }
  pageMargins.setAttribute("top", "0.7");
  pageMargins.setAttribute("left", "0.6");
  pageMargins.setAttribute("bottom", "0.5");
  pageMargins.setAttribute("right", "0.0");
  pageMargins.setAttribute("header", "0");
  pageMargins.setAttribute("footer", "0");
}

const TEMPLATE_STYLE = {
  description: "18",
  price: "19",
  upc: "20",
  barcode: "5"
};

function mergeFullWidthBarcodeRows(doc) {
  const namespace = doc.documentElement.namespaceURI;
  let mergeCells = doc.getElementsByTagNameNS(namespace, "mergeCells")[0];
  if (!mergeCells) {
    mergeCells = doc.createElementNS(namespace, "mergeCells");
    const phoneticPr = doc.getElementsByTagNameNS(namespace, "phoneticPr")[0];
    doc.documentElement.insertBefore(mergeCells, phoneticPr || null);
  }

  const existingRefs = new Set(Array.from(mergeCells.children).map((cell) => cell.getAttribute("ref")));
  for (let rowBlock = 0; rowBlock < 8; rowBlock += 1) {
    const row = 5 + rowBlock * 4;
    for (let colBlock = 0; colBlock < 4; colBlock += 1) {
      const leftCol = 1 + colBlock * 2;
      const ref = `${cellRef(leftCol, row)}:${cellRef(leftCol + 1, row)}`;
      if (existingRefs.has(ref)) continue;
      const mergeCell = doc.createElementNS(namespace, "mergeCell");
      mergeCell.setAttribute("ref", ref);
      mergeCells.appendChild(mergeCell);
      existingRefs.add(ref);
    }
  }

  mergeCells.setAttribute("count", String(mergeCells.children.length));
}

function addFinalTagStyles(stylesXml) {
  if (stylesXml.includes('name="ShelfTagFinalStyles"')) return stylesXml;

  const extraStyles = [
    '<xf numFmtId="0" fontId="10" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>',
    '<xf numFmtId="8" fontId="9" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>',
    '<xf numFmtId="0" fontId="14" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center" shrinkToFit="1"/></xf>'
  ].join("");

  return stylesXml
    .replace(/<cellXfs count="18">/, '<cellXfs count="21">')
    .replace("</cellXfs>", `${extraStyles}</cellXfs>`)
    .replace(/<cellStyles count="1">/, '<cellStyles count="2">')
    .replace("</cellStyles>", '<cellStyle name="ShelfTagFinalStyles" xfId="0"/></cellStyles>');
}

function addBarcodeImagesToTemplate(files, labels, barcodeImages) {
  const usedImages = [];
  barcodeImages.forEach((image, index) => {
    if (!image) return;
    const imageNumber = usedImages.length + 1;
    files[`xl/media/barcode${imageNumber}.png`] = image;
    usedImages.push({ imageNumber, labelIndex: index });
  });

  if (!usedImages.length) return;

  files["xl/drawings/drawing1.xml"] = createBarcodeDrawingXml(usedImages);
  files["xl/drawings/_rels/drawing1.xml.rels"] = createBarcodeDrawingRels(usedImages);
  files["xl/worksheets/_rels/sheet2.xml.rels"] = addSheetDrawingRelationship(
    textFromFile(files["xl/worksheets/_rels/sheet2.xml.rels"])
  );
  files["xl/worksheets/sheet2.xml"] = addSheetDrawingElement(textFromFile(files["xl/worksheets/sheet2.xml"]));
  files["[Content_Types].xml"] = addDrawingContentTypes(textFromFile(files["[Content_Types].xml"]));
}

function createBarcodeDrawingXml(images) {
  const anchors = images.map(({ imageNumber, labelIndex }) => {
    const rowBlock = Math.floor(labelIndex / 4);
    const colBlock = labelIndex % 4;
    const col = colBlock * 2;
    const row = 4 + rowBlock * 4;
    const name = `Barcode ${imageNumber}`;
    return `
  <xdr:twoCellAnchor editAs="oneCell">
    <xdr:from><xdr:col>${col}</xdr:col><xdr:colOff>60000</xdr:colOff><xdr:row>${row}</xdr:row><xdr:rowOff>25000</xdr:rowOff></xdr:from>
    <xdr:to><xdr:col>${col + 2}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${row + 1}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>
    <xdr:pic>
      <xdr:nvPicPr>
        <xdr:cNvPr id="${imageNumber}" name="${name}"/>
        <xdr:cNvPicPr><a:picLocks noChangeAspect="1"/></xdr:cNvPicPr>
      </xdr:nvPicPr>
      <xdr:blipFill>
        <a:blip r:embed="rId${imageNumber}"/>
        <a:stretch><a:fillRect/></a:stretch>
      </xdr:blipFill>
      <xdr:spPr>
        <a:prstGeom prst="rect"><a:avLst/></a:prstGeom>
      </xdr:spPr>
    </xdr:pic>
    <xdr:clientData/>
  </xdr:twoCellAnchor>`;
  }).join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">${anchors}
</xdr:wsDr>`;
}

function createBarcodeDrawingRels(images) {
  const relationships = images.map(({ imageNumber }) => (
    `<Relationship Id="rId${imageNumber}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/barcode${imageNumber}.png"/>`
  )).join("");
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships}</Relationships>`;
}

function addSheetDrawingRelationship(relsXml) {
  if (relsXml.includes('Target="../drawings/drawing1.xml"')) return relsXml;
  const relationship = '<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/>';
  return relsXml.replace("</Relationships>", `${relationship}</Relationships>`);
}

function addSheetDrawingElement(sheetXml) {
  if (sheetXml.includes("<drawing r:id=\"rId4\"")) return sheetXml;
  return sheetXml.replace("<legacyDrawing r:id=\"rId2\"/>", "<drawing r:id=\"rId4\"/><legacyDrawing r:id=\"rId2\"/>");
}

function addDrawingContentTypes(contentTypesXml) {
  let output = contentTypesXml;
  if (!output.includes('Extension="png"')) {
    output = output.replace("<Default Extension=\"rels\"", "<Default Extension=\"png\" ContentType=\"image/png\"/><Default Extension=\"rels\"");
  }
  if (!output.includes('PartName="/xl/drawings/drawing1.xml"')) {
    output = output.replace("</Types>", '<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/></Types>');
  }
  return output;
}

function textFromFile(file) {
  if (typeof file === "string") return file;
  return new TextDecoder().decode(file);
}

function createBarcodePngBytes(value) {
  return new Promise((resolve, reject) => {
    try {
      const patterns = code128PatternsForValue(value);
      const moduleWidth = 4;
      const quietModules = 12;
      const height = 120;
      const totalModules = patterns.reduce((total, pattern) => (
        total + [...pattern].reduce((sum, width) => sum + Number(width), 0)
      ), 0);
      const canvas = document.createElement("canvas");
      canvas.width = (totalModules + quietModules * 2) * moduleWidth;
      canvas.height = height;
      const context = canvas.getContext("2d");
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.fillStyle = "#000000";

      let x = quietModules * moduleWidth;
      patterns.forEach((pattern) => {
        for (let i = 0; i < pattern.length; i += 1) {
          const width = Number(pattern[i]) * moduleWidth;
          if (i % 2 === 0) {
            context.fillRect(x, 0, width, height);
          }
          x += width;
        }
      });

      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error("The barcode image could not be created."));
          return;
        }
        blob.arrayBuffer()
          .then((buffer) => resolve(new Uint8Array(buffer)))
          .catch(reject);
      }, "image/png");
    } catch (error) {
      reject(error);
    }
  });
}

function code128PatternsForValue(value) {
  const safeValue = value || " ";
  const codes = [104];
  for (const char of safeValue) {
    const code = char.charCodeAt(0) - 32;
    if (code < 0 || code > 95) {
      throw new Error("Code 128 barcode supports standard printable keyboard characters.");
    }
    codes.push(code);
  }

  let checksum = codes[0];
  for (let index = 1; index < codes.length; index += 1) {
    checksum += codes[index] * index;
  }
  codes.push(checksum % 103, 106);
  return codes.map((code) => CODE_128_PATTERNS[code]);
}

function setCellText(doc, ref, value) {
  const cell = findCell(doc, ref);
  if (!cell) return;
  clearCell(cell);
  if (!value) return;

  cell.setAttribute("t", "inlineStr");
  const namespace = doc.documentElement.namespaceURI;
  const inlineString = doc.createElementNS(namespace, "is");
  const text = doc.createElementNS(namespace, "t");
  text.textContent = value;
  inlineString.appendChild(text);
  cell.appendChild(inlineString);
}

function setCellValue(doc, ref, numberValue, fallbackText) {
  const cell = findCell(doc, ref);
  if (!cell) return;
  clearCell(cell);

  if (typeof numberValue === "number" && Number.isFinite(numberValue)) {
    const value = doc.createElementNS(doc.documentElement.namespaceURI, "v");
    value.textContent = String(numberValue);
    cell.appendChild(value);
    return;
  }

  setCellText(doc, ref, fallbackText);
}

function setCellStyle(doc, ref, styleId) {
  const cell = findCell(doc, ref);
  if (!cell) return;
  cell.setAttribute("s", styleId);
}

function clearCell(cell) {
  cell.removeAttribute("t");
  Array.from(cell.childNodes).forEach((child) => cell.removeChild(child));
}

function findCell(doc, ref) {
  const cells = doc.getElementsByTagNameNS(doc.documentElement.namespaceURI, "c");
  return Array.from(cells).find((cell) => cell.getAttribute("r") === ref);
}

function cellRef(column, row) {
  return `${columnName(column)}${row}`;
}

function priceNumber(value) {
  const cleaned = String(value || "").replace(/[$,]/g, "").trim();
  if (!cleaned) return null;
  const parsed = Number(cleaned);
  return Number.isFinite(parsed) ? parsed : null;
}

function createXlsxWorkbook(rows) {
  const sheetXml = worksheetXml(rows);
  const files = {
    "[Content_Types].xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`,
    "_rels/.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>`,
    "docProps/app.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
  <Application>Shelf Tag Maker</Application>
</Properties>`,
    "docProps/core.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <dc:title>Shelf Tags</dc:title>
  <dc:creator>Shelf Tag Maker</dc:creator>
  <cp:lastModifiedBy>Shelf Tag Maker</cp:lastModifiedBy>
  <dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:created>
  <dcterms:modified xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:modified>
</cp:coreProperties>`,
    "xl/workbook.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="Shelf Tags" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>`,
    "xl/_rels/workbook.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`,
    "xl/styles.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><name val="Arial"/></font></fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>`,
    "xl/worksheets/sheet1.xml": sheetXml
  };

  return zipFiles(files);
}

function worksheetXml(rows) {
  const columnWidths = [10, 34, 12, 18, 18, 22];
  const columns = columnWidths
    .map((width, index) => `<col min="${index + 1}" max="${index + 1}" width="${width}" customWidth="1"/>`)
    .join("");
  const sheetData = rows
    .map((row, rowIndex) => {
      const cells = row.map((cell, colIndex) => {
        const ref = `${columnName(colIndex + 1)}${rowIndex + 1}`;
        const style = rowIndex === 0 ? ` s="1"` : "";
        return `<c r="${ref}" t="inlineStr"${style}><is><t>${escapeXml(cell)}</t></is></c>`;
      }).join("");
      return `<row r="${rowIndex + 1}">${cells}</row>`;
    })
    .join("");

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <cols>${columns}</cols>
  <sheetData>${sheetData}</sheetData>
</worksheet>`;
}

function columnName(index) {
  let name = "";
  while (index > 0) {
    const remainder = (index - 1) % 26;
    name = String.fromCharCode(65 + remainder) + name;
    index = Math.floor((index - 1) / 26);
  }
  return name;
}

function escapeXml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function zipFiles(files) {
  const encoder = new TextEncoder();
  const parts = [];
  const centralDirectory = [];
  let offset = 0;

  Object.entries(files).forEach(([name, content]) => {
    const nameBytes = encoder.encode(name);
    const data = content instanceof Uint8Array ? content : encoder.encode(content);
    const crc = crc32(data);
    const localHeader = zipLocalHeader(nameBytes, data.length, crc);
    parts.push(localHeader, data);
    centralDirectory.push(zipCentralHeader(nameBytes, data.length, crc, offset));
    offset += localHeader.length + data.length;
  });

  const centralOffset = offset;
  centralDirectory.forEach((header) => {
    parts.push(header);
    offset += header.length;
  });
  parts.push(zipEndRecord(centralDirectory.length, offset - centralOffset, centralOffset));
  return new Blob(parts);
}

function zipLocalHeader(nameBytes, size, crc) {
  const header = new Uint8Array(30 + nameBytes.length);
  const view = new DataView(header.buffer);
  view.setUint32(0, 0x04034b50, true);
  view.setUint16(4, 20, true);
  view.setUint16(6, 0, true);
  view.setUint16(8, 0, true);
  view.setUint16(10, dosTime(), true);
  view.setUint16(12, dosDate(), true);
  view.setUint32(14, crc, true);
  view.setUint32(18, size, true);
  view.setUint32(22, size, true);
  view.setUint16(26, nameBytes.length, true);
  header.set(nameBytes, 30);
  return header;
}

function zipCentralHeader(nameBytes, size, crc, offset) {
  const header = new Uint8Array(46 + nameBytes.length);
  const view = new DataView(header.buffer);
  view.setUint32(0, 0x02014b50, true);
  view.setUint16(4, 20, true);
  view.setUint16(6, 20, true);
  view.setUint16(8, 0, true);
  view.setUint16(10, 0, true);
  view.setUint16(12, dosTime(), true);
  view.setUint16(14, dosDate(), true);
  view.setUint32(16, crc, true);
  view.setUint32(20, size, true);
  view.setUint32(24, size, true);
  view.setUint16(28, nameBytes.length, true);
  view.setUint32(42, offset, true);
  header.set(nameBytes, 46);
  return header;
}

function zipEndRecord(fileCount, centralSize, centralOffset) {
  const record = new Uint8Array(22);
  const view = new DataView(record.buffer);
  view.setUint32(0, 0x06054b50, true);
  view.setUint16(8, fileCount, true);
  view.setUint16(10, fileCount, true);
  view.setUint32(12, centralSize, true);
  view.setUint32(16, centralOffset, true);
  return record;
}

function dosTime() {
  const date = new Date();
  return (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
}

function dosDate() {
  const date = new Date();
  return ((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
}

function crc32(data) {
  let crc = 0xffffffff;
  for (let i = 0; i < data.length; i += 1) {
    crc = CRC_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

const CRC_TABLE = (() => {
  const table = [];
  for (let i = 0; i < 256; i += 1) {
    let value = i;
    for (let bit = 0; bit < 8; bit += 1) {
      value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
    }
    table.push(value >>> 0);
  }
  return table;
})();

form.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    state.labels[state.activeIndex] = currentFormData();
    advance();
    clearForm();
    renderSheet();
    updateStatus();
    save();
  } catch (error) {
    alert(error.message);
  }
});

fields.orderNumber.addEventListener("input", () => {
  if (!fields.barcodeValue.value.trim()) {
    fields.barcodeValue.placeholder = fields.orderNumber.value.trim();
  }
});

document.querySelector("#skipButton").addEventListener("click", () => {
  advance();
  renderSheet();
  updateStatus();
  save();
});

undoButton.addEventListener("click", () => {
  const previous = Math.max(0, state.activeIndex - 1);
  state.activeIndex = previous;
  if (state.labels[previous]) loadLabelIntoForm(state.labels[previous]);
  renderSheet();
  updateStatus();
  save();
});

document.querySelector("#printButton").addEventListener("click", () => window.print());
document.querySelector("#pdfButton").addEventListener("click", (event) => {
  const button = event.currentTarget;
  button.disabled = true;
  try {
    exportPdf();
  } catch (error) {
    alert(error.message || "The PDF file could not be created.");
  } finally {
    button.disabled = false;
  }
});
document.querySelector("#clearButton").addEventListener("click", () => {
  if (!confirm("Clear all 32 labels?")) return;
  state.labels = Array.from({ length: TOTAL_LABELS }, () => null);
  state.activeIndex = 0;
  clearForm();
  renderSheet();
  updateStatus();
  save();
});

init();
